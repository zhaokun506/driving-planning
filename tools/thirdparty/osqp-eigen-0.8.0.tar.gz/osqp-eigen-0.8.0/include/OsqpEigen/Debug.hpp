#ifndef OSQPEIGEN_DEBUG_HPP
#define OSQPEIGEN_DEBUG_HPP

#include <iostream>

namespace OsqpEigen {
    std::ostream &debugStream();
}

#endif /* OSQPEIGEN_DEBUG_HPP */
