# C unittests

Run

```python
python generate_tests_data.py
```

to generate the tests data for each unit test.
