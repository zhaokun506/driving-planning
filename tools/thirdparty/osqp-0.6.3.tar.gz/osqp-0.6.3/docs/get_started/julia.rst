Julia
======

Julia interface can be directly installed from Julia package manager by running

.. code:: julia

   ] add OSQP


The interface code is available on `GitHub <https://github.com/osqp/OSQP.jl>`_.

